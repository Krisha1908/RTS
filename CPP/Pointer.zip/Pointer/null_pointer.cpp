#include<iostream>
using namespace std;
int main()
{
    int a = 10;
    int *p = NULL;

    if(p ==NULL)
    {
        cout<<"pointer is null";
    }
    else
    {
        cout<<"Pointer is not null";
    }
    cout<<"\n";
}